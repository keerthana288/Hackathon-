import React, { useEffect, useState } from 'react';
import { StyleSheet, Text, View, TouchableOpacity, Alert } from 'react-native';
import * as Location from 'expo-location';
import * as SMS from 'expo-sms';
import AsyncStorage from '@react-native-async-storage/async-storage';

export default function App() {
  const [location, setLocation] = useState(null);

  useEffect(() => {
    (async () => {
      let { status } = await Location.requestForegroundPermissionsAsync();
      if (status !== 'granted') {
        Alert.alert('Permission denied', 'Location permission is required');
        return;
      }

      let loc = await Location.getCurrentPositionAsync({});
      setLocation(loc);
      await AsyncStorage.setItem('lastLocation', JSON.stringify(loc));
    })();
  }, []);

  const sendSOS = async () => {
    let savedLocation = location;
    if (!savedLocation) {
      const cached = await AsyncStorage.getItem('lastLocation');
      if (cached) savedLocation = JSON.parse(cached);
    }

    let message = '🚨 SOS Alert from SafeHaven!';
    if (savedLocation) {
      message += ` Location: https://maps.google.com/?q=${savedLocation.coords.latitude},${savedLocation.coords.longitude}`;
    } else {
      message += ' Location unavailable.';
    }

    const isAvailable = await SMS.isAvailableAsync();
    if (isAvailable) {
      await SMS.sendSMSAsync(['+911234567890'], message); // Replace with trusted contact
      Alert.alert('Alert Sent', 'Emergency message sent successfully.');
    } else {
      Alert.alert('SMS not available', 'Unable to send SMS on this device.');
    }
  };

  return (
    <View style={styles.container}>
      <Text style={styles.title}>SafeHaven</Text>
      <Text style={styles.subtitle}>Women Safety & Emergency Response</Text>
      <TouchableOpacity style={styles.sosButton} onPress={sendSOS}>
        <Text style={styles.sosText}>SOS</Text>
      </TouchableOpacity>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: '#fff',
    alignItems: 'center',
    justifyContent: 'center',
  },
  title: {
    fontSize: 28,
    fontWeight: 'bold',
    marginBottom: 10,
  },
  subtitle: {
    fontSize: 14,
    marginBottom: 40,
  },
  sosButton: {
    backgroundColor: 'red',
    padding: 40,
    borderRadius: 100,
  },
  sosText: {
    color: '#fff',
    fontSize: 32,
    fontWeight: 'bold',
  },
});
