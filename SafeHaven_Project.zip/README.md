# SafeHaven – Women Safety & Emergency Response System

## Features
- One-tap SOS emergency trigger
- Works in low-network using SMS fallback
- Uses last known GPS location if live location is unavailable
- Offline-first via AsyncStorage
- Minimal UI for fast emergency access

## Setup
1. Install Node.js and Expo CLI
   npm install -g expo-cli
2. Install dependencies
   npm install
3. Run app
   expo start

## Notes
- Replace phone number in App.js with trusted contacts.
- SMS fallback works without internet.
- Designed for hackathon/demo and can be extended with backend & AI modules.
